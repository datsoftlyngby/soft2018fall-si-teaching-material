package dk.cphbusiness.rabbitfun.manualAck;

import java.io.IOException;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class AutoAckSender {
public static void main(String[] args) throws IOException {
	ConnectionFactory connfac = new ConnectionFactory();
	connfac.setHost("datdb.cphbusiness.dk");
	connfac.setVirtualHost("student");
	connfac.setUsername("student");
	connfac.setPassword("cph");
    Connection connection = connfac.newConnection();
    Channel channel = connection.createChannel();
    String exchangeName= "manualAckTrue";
    channel.exchangeDeclare(exchangeName, "direct");
    //channel.queueDeclare("manualAckTrue", false, false, false,null);
    for (int i = 0; i < 1000; i++) {
		channel.basicPublish(exchangeName, "key", null, (""+i).getBytes());
	
    }
    channel.close();
    connection.close();
}
}
